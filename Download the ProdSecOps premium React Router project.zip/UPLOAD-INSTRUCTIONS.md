# Browser-only GitHub upload instructions

1. Create a backup branch from the current `main` branch.
2. Delete the old root `main.js` and `style.css` files.
3. Replace the old root `index.html` with the React/Vite `index.html` in this package.
4. Upload every folder and file while preserving paths, especially `.github/workflows/static.yml`, `public/`, and `src/`.
5. Ensure `package.json` is at the repository root.
6. In GitHub Settings > Pages, choose GitHub Actions as the deployment source.
7. Commit to `main` and inspect the Actions run.

Do not paste literal `<br>` tags into the YAML workflow.
